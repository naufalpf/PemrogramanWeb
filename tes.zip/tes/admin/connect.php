<?php
	$conn = mysqli_connect("localhost", "yzjvincb_web2016", "w3b2016", "yzjvincb_5114100006");
	if (!$conn) {
		die ("Koneksi error");
	}
?>