<?php
  session_start ();
  session_destroy();
?>

<p>Terimakasih sudah Logout</p>
<p>Login lagi? <a href="gamelist.php">Login</a></p>
<p>Lihat hasil ? <a href="http://www.game4life.sultan.kuliahweb.com">Intip Web</a></p>
