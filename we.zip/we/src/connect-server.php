<?php
  $con=mysqli_connect("localhost","yzjvincb_stikere","5nBLQBkFcx@$","yzjvincb_5114100093");

  // Check connection
  if (mysqli_connect_errno($con)) {
    echo "MySQL database connection failed: " . mysqli_connect_error();
  }
?>